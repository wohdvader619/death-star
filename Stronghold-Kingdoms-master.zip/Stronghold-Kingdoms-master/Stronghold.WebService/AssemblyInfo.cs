﻿// Assembly Stronghold.WebService, Version 1.0.0.0

[assembly: System.Reflection.AssemblyConfiguration("")]
[assembly: System.Reflection.AssemblyTitle("Stronghold.WebService")]
[assembly: System.Diagnostics.Debuggable(System.Diagnostics.DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: System.Reflection.AssemblyCompany("Microsoft")]
[assembly: System.Runtime.CompilerServices.CompilationRelaxations(8)]
[assembly: System.Runtime.CompilerServices.RuntimeCompatibility(WrapNonExceptionThrows=true)]
[assembly: System.Reflection.AssemblyProduct("Stronghold.WebService")]
[assembly: System.Reflection.AssemblyDescription("")]
[assembly: System.Runtime.InteropServices.Guid("f24a9990-a780-461f-b969-674e56549a34")]
[assembly: System.Reflection.AssemblyFileVersion("1.0.0.0")]
[assembly: System.Runtime.InteropServices.ComVisible(false)]
[assembly: System.Reflection.AssemblyTrademark("")]
[assembly: System.Reflection.AssemblyCopyright("Copyright \x00a9 Microsoft 2009")]

