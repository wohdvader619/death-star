﻿namespace Stronghold.AuthClient
{
    using System;

    public interface ImySqlResponse
    {
        object Resultset { get; }
    }
}

