﻿namespace Stronghold.AuthClient
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void mySqlEndResponseObjectDelegate(ICardsProvider sender, object response);
}

