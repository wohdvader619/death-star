﻿namespace Stronghold.AuthClient
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void CardsEndResponseObjectDelegate(ICardsProvider sender, object response);
}

