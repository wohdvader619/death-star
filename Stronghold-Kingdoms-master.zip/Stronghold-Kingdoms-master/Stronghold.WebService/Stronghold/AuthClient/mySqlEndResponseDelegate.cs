﻿namespace Stronghold.AuthClient
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void mySqlEndResponseDelegate(ICardsProvider sender, ICardsResponse response);
}

