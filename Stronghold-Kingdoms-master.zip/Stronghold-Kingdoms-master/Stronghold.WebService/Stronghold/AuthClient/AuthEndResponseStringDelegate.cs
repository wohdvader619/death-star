﻿namespace Stronghold.AuthClient
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void AuthEndResponseStringDelegate(IAuthProvider sender, string response);
}

