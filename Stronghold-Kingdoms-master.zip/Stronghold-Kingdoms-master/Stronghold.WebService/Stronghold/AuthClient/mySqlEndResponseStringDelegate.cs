﻿namespace Stronghold.AuthClient
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void mySqlEndResponseStringDelegate(ICardsProvider sender, string response);
}

