﻿namespace Stronghold.AuthClient
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void AuthEndResponseDelegate(IAuthProvider sender, IAuthResponse response);
}

