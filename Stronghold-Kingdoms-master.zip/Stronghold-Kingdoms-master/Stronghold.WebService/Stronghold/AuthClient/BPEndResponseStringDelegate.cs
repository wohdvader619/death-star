﻿namespace Stronghold.AuthClient
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void BPEndResponseStringDelegate(IBPProvider sender, string response);
}

