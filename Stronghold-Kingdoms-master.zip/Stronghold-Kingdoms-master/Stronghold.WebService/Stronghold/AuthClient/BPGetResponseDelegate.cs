﻿namespace Stronghold.AuthClient
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void BPGetResponseDelegate(IAsyncResult asr);
}

