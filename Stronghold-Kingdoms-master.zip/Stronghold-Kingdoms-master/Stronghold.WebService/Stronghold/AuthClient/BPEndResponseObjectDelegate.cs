﻿namespace Stronghold.AuthClient
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void BPEndResponseObjectDelegate(IBPProvider sender, object response);
}

