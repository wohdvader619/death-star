﻿namespace Stronghold.AuthClient
{
    using System;

    public interface ImySqlRequest
    {
        string Query { get; set; }
    }
}

