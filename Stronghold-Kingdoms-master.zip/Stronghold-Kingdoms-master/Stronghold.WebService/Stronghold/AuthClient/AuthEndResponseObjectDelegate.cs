﻿namespace Stronghold.AuthClient
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void AuthEndResponseObjectDelegate(IAuthProvider sender, object response);
}

