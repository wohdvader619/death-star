﻿namespace Stronghold.AuthClient
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void BPEndResponseDelegate(IBPProvider sender, IBPResponse response);
}

