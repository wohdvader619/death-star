﻿namespace Stronghold.AuthClient
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void CardsEndResponseDelegate(ICardsProvider sender, ICardsResponse response);
}

