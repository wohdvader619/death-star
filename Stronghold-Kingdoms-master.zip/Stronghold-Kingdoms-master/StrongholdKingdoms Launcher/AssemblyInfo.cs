﻿// Assembly StrongholdKingdoms, Version 0.0.0.0

[assembly: System.Reflection.AssemblyTrademark("")]
[assembly: System.Reflection.AssemblyTitle("KingdomsMain")]
[assembly: System.Reflection.AssemblyDescription("")]
[assembly: System.Reflection.AssemblyCopyright("Copyright \x00a9  2010")]
[assembly: System.Reflection.AssemblyFileVersion("1.1.0.0")]
[assembly: System.Reflection.AssemblyConfiguration("")]
[assembly: System.Reflection.AssemblyCompany("Firefly Studios")]
[assembly: System.Reflection.AssemblyProduct("Stronghold Kingdoms")]
[assembly: System.Runtime.CompilerServices.CompilationRelaxations(8)]
[assembly: System.Runtime.CompilerServices.RuntimeCompatibility(WrapNonExceptionThrows=true)]

