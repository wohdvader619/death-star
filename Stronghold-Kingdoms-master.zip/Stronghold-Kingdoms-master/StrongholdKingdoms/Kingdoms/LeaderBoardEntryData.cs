﻿namespace Kingdoms
{
    using System;

    public class LeaderBoardEntryData
    {
        public bool dummy;
        public int entryID = -1;
        public int house;
        public bool male = true;
        public string name = "";
        public int standing;
        public int value;
    }
}

