﻿namespace Kingdoms
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void FacebookEventHandler(object sender, FacebookEventArgs e);
}

