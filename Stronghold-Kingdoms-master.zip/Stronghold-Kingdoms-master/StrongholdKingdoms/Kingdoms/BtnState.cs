﻿namespace Kingdoms
{
    using System;

    public enum BtnState
    {
        Inactive,
        Normal,
        MouseOver,
        Pushed
    }
}

