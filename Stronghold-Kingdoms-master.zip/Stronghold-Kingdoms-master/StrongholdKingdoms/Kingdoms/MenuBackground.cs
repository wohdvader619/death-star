﻿namespace Kingdoms
{
    public class MenuBackground : CustomSelfDrawPanel
    {
    }
}

