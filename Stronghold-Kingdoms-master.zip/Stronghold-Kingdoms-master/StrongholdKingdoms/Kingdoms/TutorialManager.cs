﻿namespace Kingdoms
{
    using System;

    public class TutorialManager
    {
        public class TutorialData
        {
        }
    }
}

