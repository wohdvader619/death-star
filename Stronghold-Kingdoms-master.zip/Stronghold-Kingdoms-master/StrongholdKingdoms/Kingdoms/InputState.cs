﻿namespace Kingdoms
{
    using System;

    public interface InputState
    {
        void getInput();
    }
}

