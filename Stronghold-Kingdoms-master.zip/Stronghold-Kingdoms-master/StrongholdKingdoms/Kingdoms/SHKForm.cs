﻿namespace Kingdoms
{
    using System.Windows.Forms;

    public class SHKForm : Form
    {
    }
}

