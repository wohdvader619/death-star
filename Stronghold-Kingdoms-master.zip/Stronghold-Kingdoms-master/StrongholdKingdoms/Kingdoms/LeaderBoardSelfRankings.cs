﻿namespace Kingdoms
{
    using System;

    public class LeaderBoardSelfRankings
    {
        public int category = -1;
        public int oldPlace;
        public int place;
        public int value;
    }
}

