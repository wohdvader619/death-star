﻿namespace Kingdoms
{
    using System;

    public interface SHKMutex
    {
        string HelloWorld();
    }
}

