﻿namespace Kingdoms
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void BigPointEventHandler(object sender, BigPointEventArgs e);
}

