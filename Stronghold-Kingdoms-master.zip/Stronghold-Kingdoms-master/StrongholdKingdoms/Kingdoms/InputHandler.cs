﻿namespace Kingdoms
{
    using System;

    public interface InputHandler
    {
        void handleInput(MouseInputState input);
    }
}

