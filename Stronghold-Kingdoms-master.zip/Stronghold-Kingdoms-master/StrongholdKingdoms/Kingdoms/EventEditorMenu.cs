﻿namespace Kingdoms
{
    using System.Windows.Forms;

    public class EventEditorMenu : UserControl
    {
    }
}

