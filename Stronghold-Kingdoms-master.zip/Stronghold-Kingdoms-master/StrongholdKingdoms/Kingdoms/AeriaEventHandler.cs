﻿namespace Kingdoms
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void AeriaEventHandler(object sender, AeriaEventArgs e);
}

