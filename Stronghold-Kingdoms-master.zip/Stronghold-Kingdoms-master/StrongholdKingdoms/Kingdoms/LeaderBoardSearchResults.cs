﻿namespace Kingdoms
{
    using System;
    using System.Collections.Generic;

    public class LeaderBoardSearchResults
    {
        public int category = -1000;
        public List<int> entries = new List<int>();
        public string searchString = "";
    }
}

