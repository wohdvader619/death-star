﻿// Assembly StrongholdKingdoms, Version 1.1.0.0

[assembly: System.Reflection.AssemblyProduct("Stronghold Kingdoms")]
[assembly: System.Reflection.AssemblyConfiguration("")]
[assembly: System.Reflection.AssemblyCopyright("Copyright \x00a9  2010")]
[assembly: System.Reflection.AssemblyCompany("Firefly Studios")]
[assembly: System.Reflection.AssemblyTrademark("")]
[assembly: System.Reflection.AssemblyTitle("Stronghold Kingdoms")]
[assembly: System.Diagnostics.Debuggable(System.Diagnostics.DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: System.Runtime.CompilerServices.CompilationRelaxations(8)]
[assembly: System.Runtime.CompilerServices.RuntimeCompatibility(WrapNonExceptionThrows=true)]
[assembly: System.Reflection.AssemblyDescription("")]
[assembly: System.Reflection.AssemblyFileVersion("1.1.0.0")]
[assembly: System.Runtime.InteropServices.Guid("97e4707f-bcf0-4c2a-9406-f9db3caaab13")]
[assembly: System.Runtime.InteropServices.ComVisible(false)]
[assembly: System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.RequestMinimum, SkipVerification=true)]

