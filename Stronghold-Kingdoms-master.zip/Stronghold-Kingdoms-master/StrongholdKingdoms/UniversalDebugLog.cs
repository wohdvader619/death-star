﻿using System;

internal class UniversalDebugLog
{
    public static void Log(string logMessage)
    {
    }
}

