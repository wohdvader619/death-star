﻿namespace Dotnetrix_Samples
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void SelectedTabPageChangeEventHandler(object sender, TabPageChangeEventArgs e);
}

